// JavaScript içeriği - kullanıcı tarafından sağlanan tam kod
const data = {
  gemgrab: {
    name: "Gem Grab",
    maps: [
      {
        name: "Minecart Madness",
        img: "https://static.brawlify.com/brawlstars/maps/minecart-madness.png",
        characters: [
          { name: "Shelly", img: "https://static.brawlify.com/brawlstars/portrait/shelly.png" },
          { name: "Colt", img: "https://static.brawlify.com/brawlstars/portrait/colt.png" },
          { name: "Poco", img: "https://static.brawlify.com/brawlstars/portrait/poco.png" },
        ],
      },
      // Diğer modlar ve haritalar buraya devam edecek (tam kod eklenir)
    ],
  }
};

const modeListEl = document.getElementById("modeList");
const contentEl = document.getElementById("content");
const searchInput = document.getElementById("searchInput");

let currentMode = Object.keys(data)[0];

function renderModeList() {
  modeListEl.innerHTML = "";
  Object.entries(data).forEach(([key, mode]) => {
    const li = document.createElement("li");
    const a = document.createElement("a");
    a.textContent = mode.name;
    a.href = "#";
    a.classList.toggle("active", key === currentMode);
    a.addEventListener("click", (e) => {
      e.preventDefault();
      currentMode = key;
      searchInput.value = "";
      renderModeList();
      renderContent();
    });
    li.appendChild(a);
    modeListEl.appendChild(li);
  });
}

function renderContent() {
  const filter = searchInput.value.toLowerCase();
  const modeData = data[currentMode];

  contentEl.innerHTML = `<h2>${modeData.name} Modu Haritaları</h2>`;

  modeData.maps.forEach((map) => {
    const mapNameMatch = map.name.toLowerCase().includes(filter);
    const charactersMatch = map.characters.some((c) =>
      c.name.toLowerCase().includes(filter)
    );
    if (!filter || mapNameMatch || charactersMatch) {
      const mapSection = document.createElement("section");
      mapSection.className = "map-section";

      mapSection.innerHTML = `
        <div class="map">
          <h3>${map.name}</h3>
          <img src="${map.img}" alt="${map.name}" />
          <div class="character-list">
            ${map.characters
              .map(
                (c) =>
                  `<div class="character" title="${c.name}">
                    <img src="${c.img}" alt="${c.name}" />
                    <div>${c.name}</div>
                  </div>`
              )
              .join("")}
          </div>
        </div>
      `;

      contentEl.appendChild(mapSection);
    }
  });
}

searchInput.addEventListener("input", renderContent);
renderModeList();
renderContent();
